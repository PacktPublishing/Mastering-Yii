<h1>Welcome <?php echo \Yii::$app->user->getIdentity()->fullName; ?>,</h1>
<p>This is a page that requires administrative authentication to access.</p>