<?php return [
	'dsn' => 'sqlite:/' . __DIR__ . '/../../../runtime/db.sqlite',
    'class' => 'yii\db\Connection',
	'charset' => 'utf8'
];
