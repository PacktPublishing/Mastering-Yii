<div class="site-login" style="margin-top: 100px";>
    <div class="body-content">
        <?php echo $this->render('forms/RegisterForm', [ 'model' => $model ]); ?>
    </div>
</div>