var Site = {
	init: function() {
		console.log("do stuff");
	}	
};
