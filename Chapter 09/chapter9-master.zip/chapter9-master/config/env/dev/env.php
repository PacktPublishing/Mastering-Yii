<?php return [
	'debug' => true
];