<?php return require __DIR__ . '/env/' . APPLICATION_ENV . '/db.php';
