<?php return [
	'foo' => 'bar'
];