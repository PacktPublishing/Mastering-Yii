# MyModule

An example module for Chapter 5 of the book Mastering Yii. 

@see https://github.com/masteringyii/chapter5
