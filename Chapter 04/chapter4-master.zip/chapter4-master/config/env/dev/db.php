
<?php return [
	'dsn' => 'sqlite:/' . __DIR__ . '/../../../runtime/db.sqlite',
    'class' => 'yii\db\Connection',
	'charset' => 'utf8'
];

/**
<?php return [
	'dsn' => 'mysql:host=127.0.0.1;dbname=test',
    'class' => 'yii\db\Connection',
	'username' => 'test',
	'password' => 'test',
	'charset' => 'utf8'
];
*/
